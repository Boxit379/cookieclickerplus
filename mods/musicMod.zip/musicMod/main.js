Game.registerMod("musicnotifs",{
	init:function(){
		let origPlayCue = PlayCue;
		PlayCue = function(cue,arg)
		{
			if(cue == "launch") {
				Game.Notify("Now Playing","'hover' by C418",[28,6]);
			} else if(cue == "preplay" || cue == "play") {
				Game.Notify("Now Playing","'click' by C418",[28,6]);
			} else if(cue == "ascend") {
				Game.Notify("Now Playing","'ascend' by C418",[28,6]);
			} else if(cue == "grandmapocalypse") {
				Game.Notify("Now Playing","'grandmapocalypse' by C418",[28,6]);
			}
			origPlayCue(cue,arg);
		}
	}
});